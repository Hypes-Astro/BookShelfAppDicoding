// variabel LOCAL STORAGE
const localBooksKey = 'Local_Books';

// ------------------------------

// variabel pada form -------------------
const iJudul = document.getElementById("inputBookTitle");
const iAuthor = document.getElementById("inputBookAuthor");
const iYear = document.getElementById("inputBookYear");
const iCheck = document.getElementById("inputBookIsComplete");
const submitBook = document.getElementById("inputBook");
//  -----------------------------------

// variabel untuk Array Object dan untuk identifikasi buku

let books = [];
let book;
const idBook = "bookId";

// --------------------------------

// variabel untuk gunakan function membedakan sudah dan belum selesai

const id_done = document.getElementById("completeBookshelfList");
const id_undone = document.getElementById("incompleteBookshelfList");









